# Fixed GitHub Pages Package

## Important
This version fixes the previous package issue: the Founder Research PDF section is now inserted directly into the Founder section of `index.html`.

## Required repository structure
Keep this exact structure when committing to GitHub:

- `index.html`
- `.nojekyll`
- `documents/research-concept-dlg-seminar.pdf`

## Founder section buttons
The website includes two visible buttons:
- **OPEN FULL RESEARCH PDF** — opens the PDF in a new browser tab.
- **DOWNLOAD RESEARCH PDF** — downloads the PDF.

Both buttons use this relative path:
`documents/research-concept-dlg-seminar.pdf`

Do not rename or move the `documents` folder or the PDF after uploading to GitHub.

## GitHub Pages deployment
Commit the entire package contents to the branch and folder selected in GitHub Pages settings, preserving the directory structure.
